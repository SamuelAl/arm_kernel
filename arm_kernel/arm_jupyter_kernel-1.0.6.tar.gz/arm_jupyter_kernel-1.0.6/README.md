# ARM Assembly Language Kernel for Jupyter

## Installation

### From PyPI

To install `arm-jupyter-kernel` from PyPI:

```console
pip install arm-jupyter-kernel
python -m arm_kernel.install
```


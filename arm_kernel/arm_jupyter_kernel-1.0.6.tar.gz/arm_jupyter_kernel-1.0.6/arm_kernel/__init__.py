"""An ARM Jupyter kernel"""

__version__ = '1.0.6'

from .arm_kernel import ArmKernel